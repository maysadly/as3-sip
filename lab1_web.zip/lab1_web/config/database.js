// In-memory database for development
const items = [];

module.exports = { items };